var open_file 	= '../images/tinybutton-hide.gif';
var closed_file	= '../images/tinybutton-show.gif';
var node_file	= 'my_cc_node.gif';
